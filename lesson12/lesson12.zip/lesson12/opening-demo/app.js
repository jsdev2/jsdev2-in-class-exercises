$('.click-me').on('click', function() {
   console.log("I got clicked");
 });

['apples', 'oranges'].forEach(function(fruit) {
  console.log(fruit);
});
