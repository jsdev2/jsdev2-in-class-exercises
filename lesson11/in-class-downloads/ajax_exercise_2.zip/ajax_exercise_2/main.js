
// - Sign up for openweathermap.org and generate an API key.
// - User either $.ajax or $.get to pull weather current data .
//   for Washington DC 

// - Print the temperature in console.

// - Bonus 1: add a form prompting user for the city and state.
// - Bonus 2: convert answer from Kelvin to Fahrenheit.

// Something it might be helpful to know: in GET requests you
// send queries to the server in your url. You have a series
// of key-value pairs starting with a question mark, and all
// the key-value pairs are separated by an ampersand. So since
// you'll find that the name of the main parameter for the open
// weather API is "q", and the name of your API key parameter is 
// "appid", your url for this exercise will be something like:
// http://api.openweathermap.org/data/2.5/weather?q=LOCATION_YOU_ARE_CHECKING>&appid=YOUR_APP_ID



var weatherUrl = "http://api.openweathermap.org/data/2.5/weather?q=LOCATION_YOU_ARE_CHECKING&appid=YOUR_APP_ID";

