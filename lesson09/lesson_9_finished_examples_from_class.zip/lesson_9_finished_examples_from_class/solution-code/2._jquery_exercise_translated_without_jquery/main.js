/*Create a Checklist: Independent Practice

You'll add the ability to complete tasks in your favorite things list. Your program must complete the following rules:

- Using jQuery, add a "complete task" link at the end of each favorite thing (i.e. each "favorite thing").
- When clicked, the link will cross out the current item (hint: add a class to the list that sets the text-decoration to line-through).
- Each new item added by the user needs to also have the "complete task" link at the end.

*/

function addToList(list, thing) {
  var thingLi = document.createElement('li');
  thingLi.innerHTML = thing;
  list.appendChild(thingLi);
  addCompleteLink(thingLi);
}

function addCompleteLink(li) {
  var completeLink = document.createElement('span');
  completeLink.innerHTML = ' complete task';
  completeLink.classList.add('complete-task');
  li.appendChild(completeLink);
  completeLink.onclick = function(event) {
    // We don't need `event.preventDefault()` here
    // because there is no weird default action
    // when clicking on a `span` element.
    li.classList.add('completed');
  };
}

window.onload = function() {
  var thingList = document.querySelector('#fav-list');
  var button = document.querySelector('#new-thing-button');
  var newThingInput = document.querySelector('#new-thing');

  var things = document.querySelectorAll('.fav-thing');

  for (var i = 0; i < things.length; i++) {
    addCompleteLink(things[i]);
  }

  button.onclick = function(event) {
    event.preventDefault();
    var newThing = newThingInput.value;
    if (newThing === '') {
      alert('You must type in a value!');
    } else {
      addToList(thingList, newThing);
      newThingInput.value = '';
    }
  };
};
