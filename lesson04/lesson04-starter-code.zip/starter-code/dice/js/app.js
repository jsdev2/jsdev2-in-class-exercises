/*

Creating a page where every time the user hits 
the "Roll Dice" button, the screen randomly 
updates the two dice. Use the html and css code 
included in the starter code folder to get started.

Follow the steps below to write your code.

1) Make a function called "roll" that does the following:

* generates a random number between 1 - 6 and store to a variable, random1
* generates a random number between 1 - 6 and store to a variable, random2
* combines "dice dice-" and random1 to form the CSS class for the first die, firstDie
* combines "dice dice-" and random2 to form the CSS class for the second die, secondDie
* gets the first die by ID and update the first die's CSS class (hint: document.getElementById)
* gets the second die by ID and update second die's CSS class (hint:document.getElementById)

2) (optional next-level bonus): See if you can eliminate all repeated code by encapsulating it in functions (Hint: you'll need to make use of the `return` statement and/or parameters, both of which we'll be discussing shortly.) 

*/
