// var a = "this is global";
// function myFunction() {
// 	var b = "this is local";
// }
// myFunction();
// console.log(b)

// // var greeting = "Hello";

// // function sayHello() {
// // 	var name = "Robert";
// // 	return greeting + " " + name;
// // }

// // var fullGreeting = sayHello();
// // console.log(fullGreeting);

// var a = 1;
// // var b = 5;

// function getScore() {
// 	b = 2;
// }

// getScore();
// console.log(a);
// console.log(b);

// function foo() {
// 	var i;
// 	for (i = )
// }

var counter = 0;

function countUp(n) {
    counter = counter + n;
}

function countDown(n) {
    counter = counter - n;
}

function printCounter() {
    console.log(counter);
}

countUp(4);
countDown(1);
printCounter();


































