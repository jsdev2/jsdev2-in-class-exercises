function Superhero(newFirstName, newSuperHeroName) {
	this.firstName = newFirstName;
	this.superheroName = newSuperHeroName;
	// console.log(this);
};

Superhero.prototype.revealIdentity = function() {
	console.log(this.firstName + ' is ' + this.superheroName);
}


var superman = new Superhero('Clark', 'Superman');
superman.revealIdentity();

var batman = new Superhero('Bruce', 'Batman');
batman.revealIdentity();



// console.log(superman.firstName + ' is ' + superman.superheroName);