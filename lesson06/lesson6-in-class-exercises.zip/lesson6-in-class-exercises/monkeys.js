function Monkey(newName, newSpecies) {
	this.name = newName;
	this.species = newSpecies;
	this.foodsEaten = [];
}

Monkey.prototype.eatSomething = function(thingToEat) {
	this.foodsEaten.push(thingToEat);
}

Monkey.prototype.introduce = function() {
	console.log(this.name);
	console.log(this.species);
	console.log(this.foodsEaten.toString());
}

var monkey1 = new Monkey("Harold", "howler");
var monkey2 = new Monkey("Skippy", "spider");
var monkey3 = new Monkey("Emperor", "vervet");

// console.log(monkey1.name);
// console.log(monkey2["species"]);

monkey3.eatSomething("banana");
monkey3.eatSomething("pizza");
monkey3.eatSomething("soda");
monkey3.eatSomething("garbage");
monkey3.eatSomething("caviar");

monkey3.introduce();




