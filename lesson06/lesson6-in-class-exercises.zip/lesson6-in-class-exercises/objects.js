
// // var myMoto = {
// // 	wheels: 2,
// // 	color: "blue",
// // 	maxSpeed: 300,
// // 	owners: ["me", "you"]
// // }

// // console.log(myMoto.color);
// // console.log(myMoto.owners[0])

// var myHouse = {};
// var myCar  = new Object();


// myHouse.windows = 6;
// myCar["doors"] = 2;
// myCar["num-of-wheels"] = 4;

// console.log(myHouse.windows);
// // console.log(myCar.doors);
// // console.log(myCar["num-of-wheels"]);

// // var numDoors = "doors";
// // console.log(myCar[numDoors]);

// var miCasa = {
// 	color: "yellow"
// };

// var suCasa = miCasa;

// console.log(miCasa);
// suCasa.color = "grey";
// console.log(miCasa);




var oldPerson = {
	name: "Sally",
	eyeColor: "blue",
	sayHi: function() {
		console.log("Hi, I'm " + this.name);
	}
};

// var message = person.sayHi();

// var person = {
// 	name: "Bob",
// 	age: 102,
// 	sayMyAge: function() {
// 		console.log("Hi, I'm " + this.name + ", I'm " + this.age);
// 	}, 
// 	setAge: function(newAge) {
// 		if (newAge < 0) {
// 			console.log("failed to set age");
// 		}
// 		else {
// 			this.age = newAge;
// 		}
// 	}
// }

// person.setAge(-26);
// person.sayMyAge();




// // console.log(sally);

// // sally.height = "5'";
// // console.log(sally);

// // sally.address = {
// // 	streetNumber: 44,
// // 	streetName: "Brighton"
// // }
// // console.log(sally);


// // console.log(sally.name);
// // console.log(sally.eyeColor);
// // console.log(sally["height"]);


var person = {
	name: "Bob",
	age: 102,
	sayMyAge: function() {
		console.log("Hi, I'm " + this.name + ", I'm " + this.age);
	}
}

var person2 = {
	name: "Jane",
	age: 62,
	sayMyAge: function() {
		console.log("Hi, I'm " + this.name + ", I'm " + this.age);
	}
}




















