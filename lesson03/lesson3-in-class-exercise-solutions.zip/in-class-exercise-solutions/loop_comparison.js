var fruits = ['apple', 'mango', 'banana'];

// while loop

var i = 0;
while (i < fruits.length) {
	console.log(fruits[i]);
	i++;
}

// for loop

for (var j = 0; j < fruits.length; j++) {
	console.log(fruits[j]);
}

// forEach

fruits.forEach(function(myFruit) {
	console.log(myFruit);
});